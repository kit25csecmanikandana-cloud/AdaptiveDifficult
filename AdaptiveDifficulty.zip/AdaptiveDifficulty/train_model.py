"""Train and save the difficulty model (report step 4, FR5).

Trains a linear regression and a decision tree on simulated player data,
keeps the one with the lower test error, and writes model.joblib plus a
plain-text report (coefficients / tree rules) so the model can be explained.
"""
import csv

import joblib
import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, r2_score
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeRegressor, export_text

from config import (
    FEATURE_NAMES, MAX_LEVEL, MIN_LEVEL, MODEL_PATH, MODEL_REPORT_PATH,
    TRAIN_DATA_PATH,
)
from simulate import make_training_data


def main(n=4000, seed=42):
    X, y = make_training_data(n, seed)

    with open(TRAIN_DATA_PATH, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(FEATURE_NAMES + ["ideal_level"])
        for row, label in zip(X, y):
            w.writerow([round(v, 4) for v in row] + [round(label, 3)])

    # fixed split; the test set is never used for training
    X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.2, random_state=seed)

    models = {
        "linear_regression": LinearRegression(),
        "decision_tree": DecisionTreeRegressor(max_depth=5, min_samples_leaf=10, random_state=seed),
    }
    results = {}
    for name, model in models.items():
        model.fit(X_tr, y_tr)
        pred = np.clip(model.predict(X_te), MIN_LEVEL, MAX_LEVEL)
        results[name] = {
            "mae": float(mean_absolute_error(y_te, pred)),
            "r2": float(r2_score(y_te, pred)),
            "within_1_level": float(np.mean(np.abs(np.round(pred) - np.round(y_te)) <= 1)),
        }

    best = min(results, key=lambda k: results[k]["mae"])
    joblib.dump(models[best], MODEL_PATH)

    lines = [
        "Model report (trained on SIMULATED player data - not real players)",
        f"Samples: {n}  train/test split: 80/20  seed: {seed}",
        "",
    ]
    for name, m in results.items():
        mark = "  <- saved as model.joblib" if name == best else ""
        lines.append(
            f"{name}: MAE={m['mae']:.3f} levels, R2={m['r2']:.3f}, "
            f"within +/-1 level={m['within_1_level']*100:.1f}%{mark}"
        )
    lines += ["", "Linear regression coefficients:"]
    lr = models["linear_regression"]
    for fname, c in zip(FEATURE_NAMES, lr.coef_):
        lines.append(f"  {fname:18s} {c:+.3f}")
    lines.append(f"  intercept          {lr.intercept_:+.3f}")
    lines += ["", "Decision tree feature importance:"]
    dt = models["decision_tree"]
    for fname, imp in sorted(zip(FEATURE_NAMES, dt.feature_importances_), key=lambda p: -p[1]):
        lines.append(f"  {fname:18s} {imp:.3f}")
    lines += ["", "Decision tree rules:", export_text(dt, feature_names=FEATURE_NAMES)]

    with open(MODEL_REPORT_PATH, "w") as f:
        f.write("\n".join(lines))

    print("\n".join(lines[:6]))
    print(f"\nSaved model: {best} -> {MODEL_PATH}")
    return results, best


if __name__ == "__main__":
    main()
