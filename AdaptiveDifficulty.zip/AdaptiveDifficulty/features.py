"""Feature preparation (report section 4.7: scale recent metrics to a common range)."""
import math

from config import MAX_LEVEL, ROUND_LENGTH, WINDOW

REACTION_CAP = 1.5  # seconds; slower reactions are treated as 1.5


def is_valid_round(rec):
    """Validation rule for logged metrics (report section 4.8).

    Metrics must be numeric and sensible: accuracy within 0..1,
    times not negative, no NaN/inf. Invalid rows are skipped.
    """
    try:
        t = float(rec["survival_time"])
        a = float(rec["accuracy"])
        r = float(rec["reaction_time"])
    except (KeyError, TypeError, ValueError):
        return False
    if not all(math.isfinite(v) for v in (t, a, r)):
        return False
    return t >= 0 and 0.0 <= a <= 1.0 and r >= 0


def make_features(history, level, window=WINDOW):
    """Turn the last few rounds into a scaled feature vector.

    history: list of dicts with survival_time, accuracy, reaction_time, died.
    Returns None when there is no usable history.
    """
    recent = [r for r in history if is_valid_round(r)][-window:]
    if not recent:
        return None
    n = len(recent)
    survival = sum(float(r["survival_time"]) for r in recent) / n
    accuracy = sum(float(r["accuracy"]) for r in recent) / n
    reaction = sum(min(float(r["reaction_time"]), REACTION_CAP) for r in recent) / n
    deaths = sum(1 for r in recent if r.get("died")) / n
    return [
        min(survival / ROUND_LENGTH, 1.0),
        accuracy,
        reaction / REACTION_CAP,
        deaths,
        level / MAX_LEVEL,
    ]
