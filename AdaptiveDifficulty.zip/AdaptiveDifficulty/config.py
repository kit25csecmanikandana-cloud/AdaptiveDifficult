"""Shared settings for the Adaptive Difficulty System.

All numbers here are placeholders that can be tuned (see Appendix C of the
project report: difficulty range, maximum step, update interval, paths).
"""
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
LOG_PATH = os.path.join(BASE_DIR, "player_log.csv")
MODEL_PATH = os.path.join(BASE_DIR, "model.joblib")
TRAIN_DATA_PATH = os.path.join(BASE_DIR, "training_data.csv")
MODEL_REPORT_PATH = os.path.join(BASE_DIR, "model_report.txt")
EVAL_CSV_PATH = os.path.join(BASE_DIR, "evaluation_results.csv")
EVAL_PLOT_PATH = os.path.join(BASE_DIR, "evaluation_plots.png")

# Difficulty range and smoothing
MIN_LEVEL = 1
MAX_LEVEL = 10
DEFAULT_LEVEL = 5          # fallback / starting level
MAX_STEP = 1               # largest change in level per update
WINDOW = 3                 # number of recent rounds used as model input

# Round settings
ROUND_LENGTH = 60.0        # seconds a player must survive to finish a round

# Difficulty parameter mapping (level -> enemy speed, health, spawn rate)
BASE_SPEED = 80.0          # pixels per second
BASE_HEALTH = 1
BASE_SPAWN = 0.6           # enemies per second

MODES = ("static", "rule_based", "adaptive")

# Order of model input features (see features.py)
FEATURE_NAMES = [
    "survival_time",       # mean over the window, scaled by ROUND_LENGTH
    "accuracy",            # mean over the window (already 0 to 1)
    "reaction_time",       # mean over the window, scaled by 1.5 s
    "deaths",              # deaths in the window / rounds in the window
    "difficulty_level",    # level in force, scaled by MAX_LEVEL
]
