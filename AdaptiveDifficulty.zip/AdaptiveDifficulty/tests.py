"""Automated checks for the test cases in report chapter 7 that can run without a window.

Run:  python tests.py
"""
import os
import random
import tempfile
import unittest

from config import MAX_LEVEL, MAX_STEP, MIN_LEVEL, MODEL_PATH
from difficulty import DifficultyController, apply_level
from game import World
from logger import FIELDS, log_round
from predictor import Predictor


def good_row(**over):
    row = {"session_id": 1, "round": 1, "survival_time": 40.0, "accuracy": 0.6,
           "reaction_time": 0.5, "deaths": 1, "difficulty_level": 5, "mode": "adaptive"}
    row.update(over)
    return row


def rec(survival, accuracy, reaction, died):
    return {"survival_time": survival, "accuracy": accuracy,
            "reaction_time": reaction, "died": died}


class TestGame(unittest.TestCase):
    def test_tc1_round_runs(self):  # TC1
        w = World(5, random.Random(1))
        for _ in range(300):
            w.step(1 / 30, 0, 0, True)
        self.assertTrue(w.enemies or w.score > 0 or w.finished)

    def test_tc2_parameters_reflect_level(self):  # TC2
        low, high = apply_level(1), apply_level(10)
        for key in low:
            self.assertGreater(high[key], low[key])
        self.assertEqual(World(1).params, low)

    def test_tc12_parameter_bounds(self):  # TC12
        for level in (-5, MIN_LEVEL, MAX_LEVEL, 99):
            p = apply_level(level)
            lo, hi = apply_level(MIN_LEVEL), apply_level(MAX_LEVEL)
            for k in p:
                self.assertTrue(lo[k] <= p[k] <= hi[k])


class TestLogger(unittest.TestCase):
    def setUp(self):
        self.path = os.path.join(tempfile.mkdtemp(), "log.csv")

    def test_tc3_valid_row_written(self):  # TC3
        self.assertTrue(log_round(good_row(), self.path))
        with open(self.path) as f:
            self.assertEqual(len(f.read().strip().splitlines()), 2)  # header + row
        with open(self.path) as f:
            self.assertEqual(f.readline().strip().split(","), FIELDS)

    def test_tc4_invalid_rows_skipped(self):  # TC4
        for bad in (good_row(accuracy=1.5), good_row(survival_time=-1),
                    good_row(reaction_time="abc"), good_row(mode="cheat"),
                    {"round": 1}):
            self.assertFalse(log_round(bad, self.path))
        self.assertFalse(os.path.exists(self.path))


class TestModelAndController(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        if not os.path.exists(MODEL_PATH):
            import train_model
            train_model.main()
        cls.predictor = Predictor()

    def test_tc5_model_loaded(self):  # TC5
        self.assertTrue(self.predictor.available)

    def test_tc6_weak_below_strong(self):  # TC6
        from features import make_features
        weak = [rec(12, 0.3, 1.1, True)] * 3
        strong = [rec(60, 0.9, 0.35, False)] * 3
        lo = self.predictor.predict(make_features(weak, 5))
        hi = self.predictor.predict(make_features(strong, 5))
        self.assertLess(lo, hi)

    def test_tc7_good_round_rises_by_at_most_one_step(self):  # TC7
        ctrl = DifficultyController("adaptive", self.predictor, 5)
        new = ctrl.update([rec(60, 0.95, 0.3, False)] * 3)
        self.assertGreaterEqual(new, 5)
        self.assertLessEqual(new - 5, MAX_STEP)

    def test_tc8_early_deaths_fall_gradually(self):  # TC8
        ctrl = DifficultyController("adaptive", self.predictor, 5)
        history = []
        for _ in range(12):
            before = ctrl.level
            history.append(rec(8, 0.25, 1.3, True))
            after = ctrl.update(history)
            self.assertLessEqual(before - after, MAX_STEP)
            self.assertGreaterEqual(after, MIN_LEVEL)
        self.assertLess(ctrl.level, 5)

    def test_tc9_missing_model_falls_back(self):  # TC9
        missing = Predictor(os.path.join(tempfile.mkdtemp(), "nope.joblib"))
        self.assertFalse(missing.available)
        ctrl = DifficultyController("adaptive", missing, 5)
        self.assertEqual(ctrl.update([rec(40, 0.6, 0.5, True)]), 5)
        self.assertEqual(ctrl.fallbacks, 1)

    def test_static_never_changes(self):
        ctrl = DifficultyController("static", None, 3)
        self.assertEqual(ctrl.update([rec(5, 0.1, 1.4, True)] * 3), 3)

    def test_rule_based_moves_one_step(self):
        ctrl = DifficultyController("rule_based", None, 5)
        self.assertEqual(ctrl.update([rec(60, 0.8, 0.4, False)] * 3), 6)
        self.assertEqual(ctrl.update([rec(10, 0.2, 1.3, True)] * 3), 5)


if __name__ == "__main__":
    unittest.main(verbosity=2)
