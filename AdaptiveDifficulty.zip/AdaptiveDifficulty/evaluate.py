"""Static vs rule-based vs adaptive comparison (report step 6, FR8-FR10, section 7.4).

Runs the same simulated players through each mode and compares survival time,
death rate and how much the difficulty level moves.

NOTE: the players are SIMULATED (see simulate.py). The numbers describe this
simulation only; they are not results from real players.
"""
import csv
import os
import random
import statistics

from config import (
    DEFAULT_LEVEL, EVAL_CSV_PATH, EVAL_PLOT_PATH, MODEL_PATH, MODES,
)
from difficulty import DifficultyController
from predictor import Predictor
from simulate import PROFILES, simulate_round

SESSIONS = 300       # simulated players per profile
ROUNDS = 20          # rounds per session
SKILL_JITTER = 0.05  # each simulated player differs slightly from the profile


def run_session(mode, skill, seed, predictor):
    rng = random.Random(seed)
    ctrl = DifficultyController(mode, predictor, DEFAULT_LEVEL)
    history, rounds, changes = [], [], []
    for _ in range(ROUNDS):
        level = ctrl.level
        rec = simulate_round(skill, level, rng)
        rec["level"] = level
        history.append(rec)
        rounds.append(rec)
        changes.append(abs(ctrl.update(history) - level))
    return rounds, changes


def evaluate(predictor=None, seed=2026):
    predictor = predictor or Predictor()
    rows = []
    for mode in MODES:
        for profile, base_skill in PROFILES.items():
            skill_rng = random.Random(f"{seed}-{profile}")  # same players in every mode
            surv, died, levels, changes = [], [], [], []
            for s in range(SESSIONS):
                skill = min(1.0, max(0.0, base_skill + skill_rng.gauss(0, SKILL_JITTER)))
                rounds, ch = run_session(mode, skill, seed * 1000 + s, predictor)
                surv += [r["survival_time"] for r in rounds]
                died += [1 if r["died"] else 0 for r in rounds]
                levels += [r["level"] for r in rounds]
                changes += ch
            rows.append({
                "mode": mode,
                "profile": profile,
                "avg_survival_s": round(statistics.mean(surv), 2),
                "death_rate": round(statistics.mean(died), 3),
                "avg_level": round(statistics.mean(levels), 2),
                "avg_level_change": round(statistics.mean(changes), 3),
            })
    return rows


def spread_by_mode(rows):
    """Gap between the highest and lowest profile survival time, per mode."""
    out = {}
    for mode in MODES:
        vals = [r["avg_survival_s"] for r in rows if r["mode"] == mode]
        out[mode] = round(max(vals) - min(vals), 2)
    return out


def save_csv(rows, path=EVAL_CSV_PATH):
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)


def save_plot(rows, path=EVAL_PLOT_PATH):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    # validated categorical slots 1-3 (blue, orange, aqua), fixed order
    colors = {"static": "#2a78d6", "rule_based": "#eb6834", "adaptive": "#1baf7a"}
    names = {"static": "Static (level 5)", "rule_based": "Rule-based", "adaptive": "Adaptive (ML)"}
    profiles = list(PROFILES)
    width = 0.26

    fig, axes = plt.subplots(1, 2, figsize=(11, 4.6), facecolor="#fcfcfb")
    panels = [
        ("avg_survival_s", "Average survival time (seconds)", "{:.0f}"),
        ("death_rate", "Death rate (share of rounds ending in death)", "{:.0%}"),
    ]
    for ax, (key, title, fmt) in zip(axes, panels):
        ax.set_facecolor("#fcfcfb")
        for i, mode in enumerate(MODES):
            vals = [next(r[key] for r in rows if r["mode"] == mode and r["profile"] == p)
                    for p in profiles]
            xs = [j + (i - 1) * (width + 0.02) for j in range(len(profiles))]
            ax.bar(xs, vals, width, color=colors[mode], label=names[mode])
            for x, v in zip(xs, vals):
                ax.text(x, v, fmt.format(v), ha="center", va="bottom",
                        fontsize=8, color="#52514e")
        ax.set_xticks(range(len(profiles)))
        ax.set_xticklabels([p.capitalize() for p in profiles], color="#0b0b0b")
        ax.set_title(title, fontsize=10, color="#0b0b0b", loc="left")
        ax.grid(axis="y", color="#e6e5e1", linewidth=0.8)
        ax.set_axisbelow(True)
        for side in ("top", "right", "left"):
            ax.spines[side].set_visible(False)
        ax.spines["bottom"].set_color("#c3c2b7")
        ax.tick_params(colors="#52514e", length=0)
        ax.set_ylim(0, ax.get_ylim()[1] * 1.12)
        if key == "death_rate":
            from matplotlib.ticker import PercentFormatter
            ax.yaxis.set_major_formatter(PercentFormatter(1.0, decimals=0))
    axes[0].legend(frameon=False, fontsize=9, loc="upper left")
    fig.suptitle("Simulated players: static vs rule-based vs adaptive difficulty",
                 x=0.01, ha="left", fontsize=11, color="#0b0b0b")
    fig.tight_layout(rect=(0, 0, 1, 0.94))
    fig.savefig(path, dpi=150)
    plt.close(fig)


def main():
    if not os.path.exists(MODEL_PATH):
        print("No model found - training one first...")
        import train_model
        train_model.main()
    rows = evaluate()
    save_csv(rows)
    save_plot(rows)
    print(f"{'mode':11s} {'profile':13s} {'surv(s)':>8s} {'death':>7s} {'level':>6s} {'chg':>6s}")
    for r in rows:
        print(f"{r['mode']:11s} {r['profile']:13s} {r['avg_survival_s']:8.2f} "
              f"{r['death_rate']:7.3f} {r['avg_level']:6.2f} {r['avg_level_change']:6.3f}")
    print("\nSurvival-time spread across the three profiles (smaller = more consistent):")
    for mode, gap in spread_by_mode(rows).items():
        print(f"  {mode:11s} {gap:6.2f} s")
    print(f"\nSaved {EVAL_CSV_PATH}\nSaved {EVAL_PLOT_PATH}")


if __name__ == "__main__":
    main()
