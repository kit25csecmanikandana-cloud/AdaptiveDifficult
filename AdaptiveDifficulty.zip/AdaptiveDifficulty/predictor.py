"""Loads the trained scikit-learn model and predicts a difficulty level."""
import os

from config import MODEL_PATH


class Predictor:
    """Wraps the saved model. A missing or corrupt file never crashes the game."""

    def __init__(self, path=MODEL_PATH):
        self.model = None
        if os.path.exists(path):
            try:
                import joblib
                self.model = joblib.load(path)
            except Exception:
                self.model = None

    @property
    def available(self):
        return self.model is not None

    def predict(self, features):
        """Return a difficulty value (float). Raises if no model is loaded."""
        if self.model is None:
            raise RuntimeError("no model loaded")
        return float(self.model.predict([features])[0])
