"""2D Pygame game with adjustable difficulty (report steps 1-3 and 5).

Controls
  Menu:   1/2/3 static Easy/Medium/Hard   R rule-based   A adaptive   ESC quit
  Game:   arrow keys or WASD to move, SPACE to shoot
  Summary: SPACE next round   M menu   ESC quit   D toggles the debug line

Survive 60 seconds to finish a round. If an enemy touches you or reaches
the bottom of the screen the round ends and counts as a death.

Run:        python game.py
Self-test:  python game.py --selftest     (no window needed)
"""
import os
import random
import sys
import time

from config import DEFAULT_LEVEL, LOG_PATH, MODES, ROUND_LENGTH
from difficulty import DifficultyController, apply_level
from logger import log_round
from predictor import Predictor

W, H = 800, 600
FPS = 60
PLAYER_SIZE = (40, 40)
ENEMY_SIZE = (36, 36)
BULLET_SIZE = (6, 14)
PLAYER_SPEED = 320.0
BULLET_SPEED = 620.0
FIRE_COOLDOWN = 0.25
NO_HIT_REACTION = 1.5   # reaction time recorded when the player never hit anything


def overlap(ax, ay, asz, bx, by, bsz):
    """Axis-aligned overlap test for two boxes given by centre and size."""
    return abs(ax - bx) * 2 < asz[0] + bsz[0] and abs(ay - by) * 2 < asz[1] + bsz[1]


class Enemy:
    def __init__(self, x, speed, health, spawn_time):
        self.x, self.y = x, -ENEMY_SIZE[1] / 2
        self.speed = speed
        self.health = health
        self.max_health = health
        self.spawn_time = spawn_time
        self.was_hit = False


class World:
    """Game state for one round. No drawing here, so it can be tested headless."""

    def __init__(self, level, rng=None):
        self.level = level
        self.params = apply_level(level)
        self.rng = rng or random.Random()
        self.t = 0.0
        self.px, self.py = W / 2, H - 70
        self.bullets = []          # [x, y]
        self.enemies = []
        self.cooldown = 0.0
        self.spawn_timer = 0.0
        self.shots = 0
        self.hits = 0
        self.score = 0
        self.reaction_times = []   # spawn -> first hit, per enemy that was hit
        self.finished = False
        self.died = False

    def step(self, dt, move_x=0, move_y=0, fire=False):
        if self.finished:
            return
        self.t += dt

        # player movement, kept on screen and in the lower part of it
        self.px = max(20, min(W - 20, self.px + move_x * PLAYER_SPEED * dt))
        self.py = max(H - 220, min(H - 30, self.py + move_y * PLAYER_SPEED * dt))

        # shooting
        self.cooldown -= dt
        if fire and self.cooldown <= 0:
            self.bullets.append([self.px, self.py - 24])
            self.shots += 1
            self.cooldown = FIRE_COOLDOWN

        # spawning at the current spawn rate
        self.spawn_timer += dt
        interval = 1.0 / self.params["spawn_rate"]
        while self.spawn_timer >= interval:
            self.spawn_timer -= interval
            x = self.rng.uniform(30, W - 30)
            self.enemies.append(Enemy(x, self.params["enemy_speed"],
                                      self.params["enemy_health"], self.t))

        # movement
        for b in self.bullets:
            b[1] -= BULLET_SPEED * dt
        self.bullets = [b for b in self.bullets if b[1] > -20]
        for e in self.enemies:
            e.y += e.speed * dt

        # bullet / enemy collisions
        for b in list(self.bullets):
            for e in self.enemies:
                if overlap(b[0], b[1], BULLET_SIZE, e.x, e.y, ENEMY_SIZE):
                    self.bullets.remove(b)
                    self.hits += 1
                    e.health -= 1
                    if not e.was_hit:
                        e.was_hit = True
                        self.reaction_times.append(self.t - e.spawn_time)
                    if e.health <= 0:
                        self.enemies.remove(e)
                        self.score += 10
                    break

        # losing: an enemy touches the player or reaches the bottom
        for e in self.enemies:
            if overlap(self.px, self.py, PLAYER_SIZE, e.x, e.y, ENEMY_SIZE) \
                    or e.y + ENEMY_SIZE[1] / 2 >= H:
                self.died = True
                self.finished = True
                return

        if self.t >= ROUND_LENGTH:
            self.finished = True

    def result(self):
        """The metrics recorded for this round (report FR3)."""
        accuracy = self.hits / self.shots if self.shots else 0.0
        reaction = (sum(self.reaction_times) / len(self.reaction_times)
                    if self.reaction_times else NO_HIT_REACTION)
        return {
            "survival_time": min(self.t, ROUND_LENGTH),
            "accuracy": accuracy,
            "reaction_time": reaction,
            "died": self.died,
            "score": self.score,
        }


# ----------------------------------------------------------------------------
# Drawing
# ----------------------------------------------------------------------------
def draw_world(pygame, screen, fonts, world, mode, round_no, deaths, show_debug):
    screen.fill((18, 20, 28))
    pygame.draw.rect(screen, (80, 200, 140),
                     (world.px - 20, world.py - 20, *PLAYER_SIZE), border_radius=6)
    for b in world.bullets:
        pygame.draw.rect(screen, (250, 220, 90),
                         (b[0] - 3, b[1] - 7, *BULLET_SIZE))
    for e in world.enemies:
        shade = 90 + int(120 * e.health / e.max_health)
        pygame.draw.rect(screen, (shade + 40, 70, 70),
                         (e.x - 18, e.y - 18, *ENEMY_SIZE), border_radius=4)
    small = fonts[0]
    screen.blit(small.render(f"Score {world.score}", True, (235, 235, 235)), (12, 10))
    screen.blit(small.render(f"Time {world.t:4.1f}/{ROUND_LENGTH:.0f}s", True, (235, 235, 235)), (12, 34))
    screen.blit(small.render(f"Round {round_no}   Deaths {deaths}", True, (235, 235, 235)), (W - 190, 10))
    screen.blit(small.render(f"Mode: {mode}", True, (235, 235, 235)), (W - 190, 34))
    if show_debug:
        p = world.params
        line = (f"Level {world.level}  speed {p['enemy_speed']:.0f}  "
                f"health {p['enemy_health']}  spawn {p['spawn_rate']:.2f}/s")
        screen.blit(small.render(line, True, (150, 170, 210)), (12, H - 26))


def draw_center(pygame, screen, fonts, lines):
    screen.fill((18, 20, 28))
    small, big = fonts
    y = 90
    for i, text in enumerate(lines):
        font = big if i == 0 else small
        surf = font.render(text, True, (235, 235, 235) if i == 0 else (190, 195, 210))
        screen.blit(surf, (W / 2 - surf.get_width() / 2, y))
        y += 64 if i == 0 else 32


# ----------------------------------------------------------------------------
# Main game
# ----------------------------------------------------------------------------
def run_game():
    import pygame

    pygame.init()
    screen = pygame.display.set_mode((W, H))
    pygame.display.set_caption("Adaptive Difficulty System - 2D Game")
    clock = pygame.time.Clock()
    fonts = (pygame.font.SysFont(None, 26), pygame.font.SysFont(None, 54))
    predictor = Predictor()

    menu_keys = {
        pygame.K_1: ("static", 3),
        pygame.K_2: ("static", 5),
        pygame.K_3: ("static", 8),
        pygame.K_r: ("rule_based", DEFAULT_LEVEL),
        pygame.K_a: ("adaptive", DEFAULT_LEVEL),
    }

    state = "menu"
    ctrl = world = None
    history, deaths, round_no, session_id = [], 0, 0, 0
    last = None
    show_debug = True

    def start_round():
        nonlocal world, round_no, state
        round_no += 1
        world = World(ctrl.level)
        state = "play"

    running = True
    while running:
        dt = min(clock.tick(FPS) / 1000.0, 0.05)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False
                elif event.key == pygame.K_d:
                    show_debug = not show_debug
                elif state == "menu" and event.key in menu_keys:
                    mode, start = menu_keys[event.key]
                    ctrl = DifficultyController(mode, predictor, start)
                    history, deaths, round_no = [], 0, 0
                    session_id = int(time.time())
                    start_round()
                elif state == "summary" and event.key in (pygame.K_SPACE, pygame.K_RETURN):
                    start_round()
                elif state == "summary" and event.key == pygame.K_m:
                    state = "menu"

        if state == "menu":
            note = "" if predictor.available else "(no model.joblib found: adaptive mode keeps level 5 - run train_model.py)"
            draw_center(pygame, screen, fonts, [
                "Adaptive Difficulty Game",
                "1 / 2 / 3   Static  Easy / Medium / Hard",
                "R   Rule-based difficulty",
                "A   Adaptive (machine learning) difficulty",
                "Move: arrows / WASD    Shoot: SPACE",
                note,
            ])
        elif state == "play":
            keys = pygame.key.get_pressed()
            mx = (keys[pygame.K_RIGHT] or keys[pygame.K_d]) - (keys[pygame.K_LEFT] or keys[pygame.K_a])
            my = (keys[pygame.K_DOWN] or keys[pygame.K_s]) - (keys[pygame.K_UP] or keys[pygame.K_w])
            world.step(dt, mx, my, keys[pygame.K_SPACE])
            draw_world(pygame, screen, fonts, world, ctrl.mode, round_no, deaths, show_debug)
            if world.finished:
                rec = world.result()
                rec["level"] = world.level
                history.append(rec)
                deaths += 1 if rec["died"] else 0
                log_round({
                    "session_id": session_id, "round": round_no,
                    "survival_time": round(rec["survival_time"], 3),
                    "accuracy": round(rec["accuracy"], 4),
                    "reaction_time": round(rec["reaction_time"], 4),
                    "deaths": deaths, "difficulty_level": world.level, "mode": ctrl.mode,
                })
                next_level = ctrl.update(history)
                last = (rec, next_level)
                state = "summary"
        elif state == "summary":
            rec, next_level = last
            draw_center(pygame, screen, fonts, [
                "Round survived!" if not rec["died"] else "Round over",
                f"Survival time: {rec['survival_time']:.1f} s    Score: {rec['score']}",
                f"Accuracy: {rec['accuracy']*100:.0f}%    Reaction time: {rec['reaction_time']:.2f} s",
                f"Deaths so far: {deaths}",
                f"Difficulty this round: {rec['level']}    Next round: {next_level}",
                "SPACE next round    M menu    ESC quit",
            ])
        pygame.display.flip()

    pygame.quit()


# ----------------------------------------------------------------------------
# Headless self-test
# ----------------------------------------------------------------------------
def bot_input(world):
    """A simple bot: slide under the lowest enemy and keep firing."""
    if world.enemies:
        target = max(world.enemies, key=lambda e: e.y)
        dx = target.x - world.px
        return (0 if abs(dx) < 6 else (1 if dx > 0 else -1)), 0, True
    return 0, 0, True


def selftest():
    import csv
    import tempfile

    tmp = os.path.join(tempfile.mkdtemp(), "selftest_log.csv")
    predictor = Predictor()
    print(f"Model available: {predictor.available}")
    rounds_per_mode = 3
    for mode in MODES:
        ctrl = DifficultyController(mode, predictor, DEFAULT_LEVEL)
        history, deaths = [], 0
        for r in range(1, rounds_per_mode + 1):
            world = World(ctrl.level, random.Random(r))
            while not world.finished:
                world.step(1 / 30, *bot_input(world))
            rec = world.result()
            rec["level"] = world.level
            history.append(rec)
            deaths += 1 if rec["died"] else 0
            ok = log_round({
                "session_id": 1, "round": r, "survival_time": rec["survival_time"],
                "accuracy": rec["accuracy"], "reaction_time": rec["reaction_time"],
                "deaths": deaths, "difficulty_level": world.level, "mode": mode,
            }, path=tmp)
            assert ok, "valid round was not logged"
            new = ctrl.update(history)
            assert abs(new - world.level) <= 1, "difficulty jumped more than one step"
            print(f"  {mode:10s} round {r}: survived {rec['survival_time']:5.1f}s "
                  f"acc {rec['accuracy']:.2f} died={rec['died']} level {world.level}->{new}")
    with open(tmp) as f:
        rows = list(csv.DictReader(f))
    assert len(rows) == rounds_per_mode * len(MODES), "log row count wrong"
    print(f"Logged {len(rows)} rows OK")

    # drawing smoke test (only if pygame is installed)
    os.environ["SDL_VIDEODRIVER"] = "dummy"
    try:
        import pygame
    except ImportError:
        print("pygame not installed: skipped drawing check")
        return
    pygame.init()
    screen = pygame.display.set_mode((W, H))
    fonts = (pygame.font.SysFont(None, 26), pygame.font.SysFont(None, 54))
    world = World(5, random.Random(1))
    for _ in range(120):
        world.step(1 / 30, *bot_input(world))
    draw_world(pygame, screen, fonts, world, "adaptive", 1, 0, True)
    draw_center(pygame, screen, fonts, ["Title", "line"])
    pygame.quit()
    print("Drawing check OK")


if __name__ == "__main__":
    if "--selftest" in sys.argv:
        selftest()
    else:
        run_game()
