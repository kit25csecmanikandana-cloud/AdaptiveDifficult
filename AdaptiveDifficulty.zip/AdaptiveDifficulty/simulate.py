"""Simulated player profiles (report section 4.5).

A simple model of how a player with a given skill (0 to 1) performs at a
given difficulty level. It is used to generate training data and to run
repeatable static / rule-based / adaptive comparisons.

IMPORTANT: this is a made-up model of players, not real player data. Any
number produced from it only describes the simulation.
"""
import random

from config import MAX_LEVEL, MIN_LEVEL, ROUND_LENGTH, WINDOW
from features import make_features

PROFILES = {"beginner": 0.15, "intermediate": 0.50, "expert": 0.90}
TARGET_SURVIVAL = 35.0   # seconds: the "challenge zone" the system aims for


def clip(x, lo, hi):
    return max(lo, min(hi, x))


def challenge(level):
    return 1 + 0.15 * (level - 1)


def base_survival(skill):
    """Typical survival time (s) at level 1."""
    return 20 + 70 * skill


def ideal_level(skill):
    """Level at which this skill's typical survival equals the target (float)."""
    c = base_survival(skill) / TARGET_SURVIVAL
    return clip(1 + (c - 1) / 0.15, MIN_LEVEL, MAX_LEVEL)


def simulate_round(skill, level, rng):
    """One simulated round. Returns the same fields the real game records."""
    mean_time = base_survival(skill) / challenge(level)
    t = mean_time * rng.lognormvariate(0, 0.25)
    died = t < ROUND_LENGTH
    return {
        "survival_time": min(t, ROUND_LENGTH),
        "accuracy": clip(0.30 + 0.60 * skill - 0.01 * (level - 1) + rng.gauss(0, 0.05), 0.05, 0.99),
        "reaction_time": clip(0.95 - 0.60 * skill + 0.03 * (level - 1) + rng.gauss(0, 0.06), 0.15, 1.5),
        "died": died,
    }


def make_training_data(n=4000, seed=42):
    """Build (features, ideal level) pairs from simulated 3-round windows.

    Each sample is a random skill playing WINDOW rounds at one random level.
    """
    rng = random.Random(seed)
    X, y = [], []
    for _ in range(n):
        skill = rng.random()
        level = rng.randint(MIN_LEVEL, MAX_LEVEL)
        history = [simulate_round(skill, level, rng) for _ in range(WINDOW)]
        X.append(make_features(history, level))
        y.append(ideal_level(skill))
    return X, y
