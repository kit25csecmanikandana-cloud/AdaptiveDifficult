# Adaptive Difficulty System for 2D Games Using Machine Learning

B.E. Computer Science and Engineering project, KIT - Kalaignarkarunanidhi Institute of Technology (KIT-CBE), Anna University.
**Author:** Manikandan A (Reg. No. 711525BCS089)  |  **Guide:** Ms. Sumathy Ramasami, Assistant Professor, CSE

A Pygame 2D shooter whose difficulty adapts to the player in real time. A small
scikit-learn model reads recent performance (survival time, accuracy, reaction
time, deaths) and predicts a difficulty level. A controller applies it to enemy
speed, enemy health and spawn rate in small, bounded steps. The adaptive mode is
compared with a static level and a rule-based baseline.

![Evaluation plots](evaluation_plots.png)

## Quick start

```bash
pip install -r requirements.txt
python train_model.py     # trains the model, writes model.joblib
python game.py            # play: A = adaptive, R = rule-based, 1/2/3 = static
python evaluate.py        # static vs rule-based vs adaptive on simulated players
python tests.py           # automated tests
python game.py --selftest # headless bot plays a few rounds in every mode
```

**Controls:** arrow keys or WASD to move, SPACE to shoot, D toggles the debug line
showing the current level, ESC quits. Each round lasts 60 seconds. An enemy that
touches you or reaches the bottom ends the round as a death.

## How it works

```
play round -> log metrics -> model predicts level -> controller moves level by <= 1 -> next round
```

| File | Role (report section) |
|---|---|
| `game.py` | Pygame game; enemy speed, health and spawn rate are adjustable (5, 6.3) |
| `difficulty.py` | Level-to-parameter mapping, static / rule-based / adaptive controllers (4.7) |
| `features.py` | Scales the last 3 rounds into model input; validity checks (4.7, 4.8) |
| `logger.py` | Validates and appends rows to `player_log.csv` (4.4) |
| `simulate.py` | Simulated beginner / intermediate / expert players (4.5) |
| `train_model.py` | Trains linear regression and decision tree, saves the better one (4.6) |
| `predictor.py` | Loads the model; a missing or corrupt file falls back safely (4.8) |
| `evaluate.py` | Static vs rule-based vs adaptive comparison and plots (7.4) |
| `tests.py` | Automated versions of test cases TC1-TC9 and TC12 (7.2) |
| `config.py` | Level range, max step, window size, paths (Appendix C) |

Model input is 5 numbers: mean survival time, mean accuracy, mean reaction time
and the share of rounds that ended in death over the last 3 rounds, plus the
level currently in force. The report lists the first four; the current level is
added because survival time means little without knowing how hard the round was.
Reaction time is measured as the time from an enemy appearing to the first
bullet that hits it.

## Results (simulated players only)

Running `python evaluate.py` (300 simulated players per profile, 20 rounds each):

| Mode | Beginner | Intermediate | Expert | Spread across profiles |
|---|---|---|---|---|
| Static (level 5) | 19.3 s | 35.3 s | 50.3 s | 31.0 s |
| Rule-based | 28.5 s | 38.4 s | 49.0 s | 20.5 s |
| Adaptive (ML) | 28.4 s | 35.5 s | 39.3 s | 10.9 s |

Average survival time per profile. The adaptive mode gives the most similar
survival times across skill levels, which matches the expected pattern in
report section 7.4.

**Read these numbers carefully:**
- The players are *simulated by a formula I wrote* (`simulate.py`), and the model
  was trained on the same kind of simulation. The model scoring well on its own
  simulated test set (MAE 0.38 levels) says the pipeline works, not that it works on
  real people.
- The target survival (35 s) is shorter than the round length (60 s), so almost every
  round ends in a death in every mode. Death rate therefore does not separate
  the modes well here; survival-time consistency is the useful signal.
- Real results need data from real playtesters (report chapters 9 and 10).
- The difficulty-to-parameter numbers are untuned placeholders (report section 4.4).

## Notes on testing

`tests.py` and `game.py --selftest` were run successfully. The game window itself
(drawing and keyboard input) needs a machine with a display and `pygame`
installed, so play it yourself and add your screenshots in Appendix D of the report.

## Project status against the report timeline

| Step | Activity | Status |
|---|---|---|
| 1 | Environment setup, base 2D game | Done |
| 2 | Adjustable enemy speed, health, spawn rate; scoring | Done |
| 3 | Data logging | Code written, tested |
| 4 | Training data and model | Code written, run on simulated data |
| 5 | Model integrated in game loop | Code written; needs your playtesting |
| 6 | Testing, tuning, adaptive vs static comparison | Simulated comparison done; tuning and human testing pending |
| 7 | Final report and demo | Pending |

## License

MIT, see `LICENSE`.
