"""Parameter mapping and difficulty controller (report sections 4.6 and 4.7).

Three controllers share one interface:
  static      - the level never changes
  rule_based  - if/else thresholds (the baseline the ML model must beat)
  adaptive    - the trained model predicts a level, applied in small steps
"""
import math

from config import (
    BASE_HEALTH, BASE_SPAWN, BASE_SPEED, DEFAULT_LEVEL, MAX_LEVEL,
    MAX_STEP, MIN_LEVEL, MODES,
)
from features import is_valid_round, make_features


def clip(x, lo, hi):
    return max(lo, min(hi, x))


def apply_level(level):
    """Monotonic mapping: higher level = faster, tougher, more frequent enemies."""
    level = clip(level, MIN_LEVEL, MAX_LEVEL)
    return {
        "enemy_speed": BASE_SPEED * (1 + 0.1 * level),
        "enemy_health": BASE_HEALTH + int(level) // 3,
        "spawn_rate": BASE_SPAWN * (1 + 0.1 * level),
    }


def rule_based_step(history):
    """Baseline thresholds on the last three rounds. Returns -1, 0 or +1."""
    recent = history[-3:]
    n = len(recent)
    deaths = sum(1 for r in recent if r.get("died"))
    survival = sum(float(r["survival_time"]) for r in recent) / n
    accuracy = sum(float(r["accuracy"]) for r in recent) / n
    if deaths == 0 and accuracy >= 0.5:
        return 1          # surviving full rounds with good aim: make it harder
    if deaths >= 2 and survival < 30:
        return -1         # repeated early deaths: make it easier
    return 0


class DifficultyController:
    def __init__(self, mode="adaptive", predictor=None, start_level=DEFAULT_LEVEL):
        if mode not in MODES:
            raise ValueError(f"mode must be one of {MODES}")
        self.mode = mode
        self.predictor = predictor
        self.level = int(clip(start_level, MIN_LEVEL, MAX_LEVEL))
        self.last_prediction = None
        self.fallbacks = 0   # times the model could not be used

    def update(self, history):
        """Call between rounds. Returns the level for the next round."""
        history = [r for r in history if is_valid_round(r)]
        if self.mode == "static" or not history:
            return self.level

        if self.mode == "rule_based":
            step = rule_based_step(history)
        else:
            step = self._ml_step(history)

        # smooth application: bounded step, bounded level
        step = clip(step, -MAX_STEP, MAX_STEP)
        self.level = int(clip(self.level + step, MIN_LEVEL, MAX_LEVEL))
        return self.level

    def _ml_step(self, history):
        try:
            features = make_features(history, self.level)
            predicted = self.predictor.predict(features)
            if not math.isfinite(predicted):
                raise ValueError("non-finite prediction")
        except Exception:
            # missing model, bad data or failed prediction: keep current level
            self.fallbacks += 1
            self.last_prediction = None
            return 0
        predicted = clip(predicted, MIN_LEVEL, MAX_LEVEL)
        self.last_prediction = predicted
        return int(round(predicted)) - self.level
