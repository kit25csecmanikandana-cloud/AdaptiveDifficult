"""Performance logging to player_log.csv (report FR3, FR4, section 4.4)."""
import csv
import os

from config import LOG_PATH, MAX_LEVEL, MIN_LEVEL, MODES
from features import is_valid_round

FIELDS = [
    "session_id",
    "round",
    "survival_time",
    "accuracy",
    "reaction_time",
    "deaths",
    "difficulty_level",
    "mode",
]


def validate_row(row):
    """True if the row has every field and sensible values."""
    if any(k not in row for k in FIELDS):
        return False
    if not is_valid_round(row):
        return False
    try:
        if int(row["deaths"]) < 0 or int(row["round"]) < 1:
            return False
        level = float(row["difficulty_level"])
        int(row["session_id"])
    except (TypeError, ValueError):
        return False
    return MIN_LEVEL <= level <= MAX_LEVEL and row["mode"] in MODES


def log_round(row, path=LOG_PATH):
    """Append one validated row. Invalid rows are skipped, never raised.

    Returns True when the row was written.
    """
    if not validate_row(row):
        return False
    new_file = not os.path.exists(path) or os.path.getsize(path) == 0
    try:
        with open(path, "a", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=FIELDS)
            if new_file:
                writer.writeheader()
            writer.writerow({k: row[k] for k in FIELDS})
    except OSError:
        return False  # a logging problem must not crash the game
    return True
